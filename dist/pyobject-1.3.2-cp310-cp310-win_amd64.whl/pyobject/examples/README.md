本目录实现了`pyobject`库的一些使用示例，包括一套pyc文件的压缩和脱壳工具链。  
完整的pyc文件加壳工具pyc-zipper工具参见：[github.com/qfcy/pyc-zipper](https://github.com/qfcy/pyc-zipper)  

---

This directory implements several examples for `pyobject` library, including a toolchain for compressing and unpacking a set of pyc files.  
For the complete pyc file packing tool, see: [github.com/qfcy/pyc-zipper](https://github.com/qfcy/pyc-zipper).  